#!/bin/bash
mv UBUNTU-WALLPAPER  /etc/
# Create the script
cat << 'EOF' > /etc/change_wallpaper.sh
#!/bin/bash
WALLPAPERS_DIR="/etc/UBUNTU-WALLPAPER/Wlp"
WALLPAPER=$(ls "$WALLPAPERS_DIR" | shuf -n 1)
gsettings set org.gnome.desktop.background picture-uri "file://$WALLPAPERS_DIR/$WALLPAPER"
EOF

# Make the script executable
chmod +x /etc/change_wallpaper.sh

# Add the directory path to ~/.bashrc
echo 'export WALLPAPERS_DIR="/etc/UBUNTU-WALLPAPER/Wlp"' >> ~/.bashrc

# Create a screen session to run the script
screen -dmS wallpaper_changer /etc/change_wallpaper.sh

